from django.apps import AppConfig


class MysiteConfig(AppConfig):
    name = 'mysite'
